import {Section} from "./table"

const App = () => {
    return Section();
}

export default App;