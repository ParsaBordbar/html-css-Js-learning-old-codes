export {
  EDITOR_TYPE,
  CheckboxEditor,
} from './checkboxEditor';
