export { autoResize } from './autoResize';
