export {
  CELL_TYPE,
  NumericCellType,
} from './numericType';

