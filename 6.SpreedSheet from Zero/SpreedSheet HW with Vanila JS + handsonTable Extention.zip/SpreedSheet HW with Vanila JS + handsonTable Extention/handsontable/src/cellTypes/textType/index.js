export {
  CELL_TYPE,
  TextCellType,
} from './textType';
